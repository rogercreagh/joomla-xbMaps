<?php
/*******
 * @package xbMaps Component
 * @version 0.3.0.c 18th September 2021
 * @filesource site/controllers/catlist.php
 * @author Roger C-O
 * @copyright Copyright (c) Roger Creagh-Osborne, 2021
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 ******/
defined('_JEXEC') or die;

class XbmapsControllerCatlist extends JControllerForm {
	
}