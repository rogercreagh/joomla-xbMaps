<?php
/*******
 * @package xbMaps
 * @version 0.5.0.c 30th September 2021
 * @filesource site/controllers/markerlist.php
 * @author Roger C-O
 * @copyright Copyright (c) Roger Creagh-Osborne, 2021
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 ******/
defined('_JEXEC') or die;

class XbmapsControllerMarkerlist extends JControllerForm {
	
}