<?php
/*******
 * @package xbMaps Component
 * @version 0.3.0.f 20th September 2021
 * @filesource site/controllers/tags.php
 * @author Roger C-O
 * @copyright Copyright (c) Roger Creagh-Osborne, 2021
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 ******/
defined('_JEXEC') or die;

class XbmapsControllerTags extends JControllerForm {
	
}